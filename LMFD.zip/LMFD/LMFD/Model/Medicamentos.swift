//
//  Medicamentos.swift
//  LMFD
//
//  Created by Elias Jesus Quinteros on 12/8/23.
//

import Foundation

struct Medicamentos: Identifiable{
    var id: String
    var nombre: String
    var farmacias: String
    var categoria: String
}
