//
//  viewModelAuth.swift
//  LMFD
//
//  Created by Elias Jesus Quinteros on 12/6/23.
//

import Foundation
import FirebaseCore
import FirebaseAuth
import FirebaseFirestore


    

    
    
    


class AppViewModel: ObservableObject {
    
    let db = Firestore.firestore()
    let auth = Auth.auth()
    
    @Published  var signedIn = false
    var isSignedIn: Bool{
        return auth.currentUser != nil
    }
    func signIn(email: String, password: String    ) {
        auth.signIn(withEmail: email, password: password){[weak self]result, error in
            guard result != nil, error     == nil else{
                return
            }
            DispatchQueue.main.async {
                self?.signedIn = true
            }
        }
    }
    func singUp(email:String, password: String) {
        auth.createUser(withEmail: email, password: password) {[weak self]result, error in
            guard result != nil, error     == nil else{
                return
            }
            DispatchQueue.main.async {
                self?.signedIn = true
            }
        }
    }
    func signOut() {
        try? auth.signOut()
        self.signedIn = false
    }
    
   
   
}
