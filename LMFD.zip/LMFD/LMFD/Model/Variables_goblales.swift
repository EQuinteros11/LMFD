//
//  Variables_goblales.swift
//  LMFD
//
//  Created by Elias Jesus Quinteros on 12/6/23.
//

import Foundation

var veruser: String = ""
var verpass: String = ""
var farmaciaD: String = "La buena\n \t\t   La Correcta\n \t\t   Brasil\n \t\t   San Nicolas"
