//
//  ViewModel.swift
//  LMFD
//
//  Created by Elias Jesus Quinteros on 12/8/23.
//

import Foundation
import FirebaseFirestore
import FirebaseFirestoreSwift
import Firebase
class ViewModel: ObservableObject {
    @Published var list = [Medicamentos]()
    
    
    func updateData(medicamentoToUpdate: Medicamentos, nombre: String, categoria: String, farmacias: String) {
        let db = Firestore.firestore()
        db.collection("Medicamentos").document(medicamentoToUpdate.id).setData(["nombre":"\(nombre)", "categoria":"\(categoria)", "farmacias":"\(farmacias)" ], merge:true){
            error in
            if error == nil{
                self.getData()
            }
            else{
                
            }
        }
    }
    
    func deletesData(medicamentoToDelete: Medicamentos) {
        let db = Firestore.firestore()
        db.collection("Medicamentos").document(medicamentoToDelete.id).delete(){
            error in
            if error == nil{
                DispatchQueue.main.async {
                    self.list.removeAll{
                        Medicamentos in
                        return Medicamentos.id == medicamentoToDelete.id
                    }
                }
            }
        }
    }
    
    func addData(nombre: String, categoria: String, farmacias: String)  {
        let db = Firestore.firestore()
        db.collection("Medicamentos").addDocument(data: ["nombre": nombre, "categoria": categoria, "farmacias": farmacias]){
            error in
            //check for error
            if error == nil{
                
                    self.getData()
                
                
            }
            else{
                
            }
        }
        
    }
    func getData() {
        let db = Firestore.firestore()
        db.collection("Medicamentos").getDocuments{
            snapshot, error in
            if error == nil{
                if let snapshot = snapshot{
                    DispatchQueue.main.async {
                        self.list = snapshot.documents.map{d in
                            return Medicamentos(id: d.documentID ,
                                                nombre: d["nombre"] as? String ?? "",
                                                farmacias: d["farmacias"] as? String ?? "",
                                                categoria: d["categoria"] as? String ?? "")
                        }
                    }
                    
                }
            }
            else{
                
            }
        }
        
    }
}
