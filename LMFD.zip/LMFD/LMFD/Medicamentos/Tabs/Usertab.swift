//
//  Usertab.swift
//  LMFD
//
//  Created by Elias Jesus Quinteros on 12/8/23.
//

import SwiftUI
import FirebaseFirestore
import FirebaseFirestoreSwift

struct Usertab: View {
    
    let db = Firestore.firestore()
    @EnvironmentObject var viewModel: AppViewModel
    var body: some View {
        Button(action: {
            viewModel.signOut()
        }, label: {
            Text("Cerrar Sesión")
                .bold()
                .font(.title)
            Image(systemName: "arrow.left")
            
        })
        .background(Color.red)
        .foregroundColor(.white)
        .font(.system(size: 30))
    }
}

struct Usertab_Previews: PreviewProvider {
    static var previews: some View {
        Usertab()
    }
}
