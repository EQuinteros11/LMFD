//
//  maintab.swift
//  LMFD
//
//  Created by Elias Jesus Quinteros on 12/8/23.
//

import SwiftUI
import FirebaseFirestore
import FirebaseCore

struct maintab: View {
    let db = Firestore.firestore()
    @ObservedObject  var model = ViewModel()
    @EnvironmentObject var viewModel: AppViewModel
    @State var buscar:String = ""
    var body: some View {
       
        VStack{
                        // CONTENEDOR 2
                        VStack (alignment: .center) {
                            // HEADER
                            VStack(alignment: .center) {
                                // LOGO
                                HStack{
                                    Image("LogoFarmacia")
                                }
                                
                                // USUARIO
                                Image(systemName: "person.circle.fill")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 50, height: 50)
                                
                                // USUARIO ACTIVO
                                Text("Bienvenido: \(veruser)")
                                        .font(.system(size: 15, weight: .semibold))
                        
                            }
                            .frame(minWidth:
                                    (UIScreen.main.bounds.width))
                            .padding(.bottom, 15)
                            .background(colorEncabezado)
                            
                            VStack {
                                VStack {
                                    TextField(
                                            "Buscar...",
                                            text: $buscar
                                    )
                                    .padding(.horizontal, 20)
                                    .padding(.vertical, 10)
                                    .keyboardType(.emailAddress)
                                    .background(colorImput)
                                    .foregroundColor(colorNegro)
                                    .cornerRadius(10)
                                    .overlay(Rectangle().stroke(Color.gray, lineWidth: 1))
                                }
                            }
                            .padding(.vertical, 10)
                            .padding(.horizontal, 10)
                            
                            // Categorias
                            VStack{
                                // Primera fila de categorias
                               
                                
                                VStack(alignment: .center){
                                    Text("Listado de Medicamentos")
                                    HStack(spacing: 10) {
                                        NavigationLink("+", destination: AddView())
                                        
                                    }
                                    
                                    List(model.list){item in
                                       
                                        
                                        VStack(alignment:.leading){
                                            
                                            
                                            VStack{
                                                
                                                HStack{
                                                    
                                                    Spacer()
                                                    NavigationLink("✏️", destination: UpdateView(i: item, nombre1: item.nombre, categoria2: item.categoria, farmacia3: item.farmacias))
                                                          .font(.system(size: 15))
                                                  
                                                  
                                                }
                                                HStack(spacing: 10){
                                                    
                                                    Text("MEDICAMENTO: \(item.nombre)")
                                                        .font(.system(size: 12))
                                                    .bold()
                                                    .alignmentGuide(.firstTextBaseline){_ in 10}
                                                        .alignmentGuide(.lastTextBaseline){_ in 10}
                                                   
                                                    
                                                        
                                                }
                                                
                                                Text("CATEGORIA: \(item.categoria) \n")
                                                    .font(.system(size: 10))
                                                .alignmentGuide(.firstTextBaseline){_ in 20}
                                                    .alignmentGuide(.lastTextBaseline){_ in 20}
                                                Text("FARMACIAS:")
                                                    .font(.system(size: 10))
                                                .alignmentGuide(.firstTextBaseline){_ in 20}
                                                    .alignmentGuide(.lastTextBaseline){_ in 20}
                                                Text(item.farmacias)
                                                    .font(.system(size: 10))
                                                .alignmentGuide(.firstTextBaseline){_ in 20}
                                                    .alignmentGuide(.lastTextBaseline){_ in 20}
                                                
                                               
                                                
                                                 
                                            
                                                
                                            }
                                            .frame(width: 290, height: 100)
                                            .background(Color.gray.opacity(0.3))
                                            .cornerRadius(20)
                                            
                                            
                                        }
                                        
                                       
                                    }
                                    
                                    
                                }
                            }
                        }
                        .padding(.top, 20)
                        .frame(minWidth:
                                (UIScreen.main.bounds.width))
                        
                     
                        
                     
                    
                }
        .onAppear{
            model.getData()
        }
                .ignoresSafeArea()
                .frame(minWidth:
                        (UIScreen.main.bounds.width))
                .background(colorImput)
                .padding(.top, 0)
    }
    
   
}

struct maintab_Previews: PreviewProvider {
    static var previews: some View {
        maintab()
    }
}
