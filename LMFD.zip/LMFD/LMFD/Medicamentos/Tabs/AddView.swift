//
//  AddView.swift
//  LMFD
//
//  Created by Elias Jesus Quinteros on 12/9/23.
//

import SwiftUI

struct AddView: View {
    @ObservedObject  var model = ViewModel()
    @State var nombre = ""
    @State var categoria = ""
    @State var farmacia = ""
    var body: some View {
        VStack(spacing: 5){
            TextField("Nombre", text: $nombre)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .autocapitalization(/*@START_MENU_TOKEN@*/.none/*@END_MENU_TOKEN@*/)
                .disableAutocorrection(/*@START_MENU_TOKEN@*/false/*@END_MENU_TOKEN@*/)
            TextField("Categoria", text: $categoria)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .autocapitalization(.none)
                .disableAutocorrection(/*@START_MENU_TOKEN@*/false/*@END_MENU_TOKEN@*/)
            TextField("Farmacia", text: $farmacia)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .autocapitalization(/*@START_MENU_TOKEN@*/.none/*@END_MENU_TOKEN@*/)
                .disableAutocorrection(/*@START_MENU_TOKEN@*/false/*@END_MENU_TOKEN@*/)
            Button(action: {
                model.addData(nombre: nombre, categoria: categoria, farmacias: farmacia)
                nombre = ""
                categoria = ""
                farmacia = ""
                
            }, label: {
                Text("Add Medicamento item")
            })
            
        }
    }

   
}

struct AddView_Previews: PreviewProvider {
    static var previews: some View {
        AddView()
    }
}
