//
//  UpdateView.swift
//  LMFD
//
//  Created by Elias Jesus Quinteros on 12/9/23.
//

import SwiftUI

struct UpdateView: View {
    
    @ObservedObject  var model = ViewModel()
    var i: Medicamentos!
    
    @State var nombre1 = ""
    @State var categoria2 = ""
    @State var farmacia3 = ""
    var body: some View {
        VStack(spacing: 5){
            TextField("Nombre", text: $nombre1)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .autocapitalization(/*@START_MENU_TOKEN@*/.none/*@END_MENU_TOKEN@*/)
                .disableAutocorrection(/*@START_MENU_TOKEN@*/false/*@END_MENU_TOKEN@*/)
            TextField("Categoria", text: $categoria2)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .autocapitalization(.none)
                .disableAutocorrection(/*@START_MENU_TOKEN@*/false/*@END_MENU_TOKEN@*/)
            TextField("Farmacia", text: $farmacia3)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .autocapitalization(/*@START_MENU_TOKEN@*/.none/*@END_MENU_TOKEN@*/)
                .disableAutocorrection(/*@START_MENU_TOKEN@*/false/*@END_MENU_TOKEN@*/)
            HStack(spacing: 15) {
                Button(action: {
                    model.updateData(medicamentoToUpdate: i, nombre: nombre1, categoria: categoria2, farmacias: farmacia3)
                    nombre1 = ""
                    categoria2 = ""
                    farmacia3 = ""
                    
                        }, label: {
                            Text("✏️Update")
                                .bold()
                    })
                .frame(width: 150, height: 50, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                .background(Color.green)
                .foregroundColor(.white)
                .cornerRadius(5)
                Button(action: {
                    model.deletesData(medicamentoToDelete: i)
                    nombre1 = ""
                    categoria2 = ""
                    farmacia3 = ""
                    
                    
                }, label: {
                    Text("🗑Delete")
                        .bold()
            })
                .frame(width: 150, height: 50, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                .background(Color.red)
                
                .foregroundColor(.white)
                .cornerRadius(5)
            }
            
        }
    }
}

struct UpdateView_Previews: PreviewProvider {
    static var previews: some View {
        UpdateView()
    }
}
