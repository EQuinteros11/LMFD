//
//  VistaPrincipal.swift
//  LMFD
//
//  Created by Elias Jesus Quinteros on 12/6/23.
//

import SwiftUI

struct VistaPrincipal: View {
    @ObservedObject  var model = ViewModel()
    
    var body: some View {
        TabView{
            maintab()
                .tabItem { Image(systemName: "house")
                    Text("Principal")
                    
                }
            Usertab()
                .tabItem { Image(systemName: "person.circle.fill")
                    Text("cuenta")
                }
           
        }
        
    }
    
    
}

struct VistaPrincipal_Previews: PreviewProvider {
    static var previews: some View {
        VistaPrincipal()
    }
}
