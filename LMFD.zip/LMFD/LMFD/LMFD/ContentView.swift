//
//  ContentView.swift
//  LMFD
//
//  Created by Elias Jesus Quinteros on 12/1/23.
//

import SwiftUI
import FirebaseAuth
import FirebaseFirestore
import FirebaseCore



struct ContentView: View {
    
    @ObservedObject  var model = ViewModel()
    @EnvironmentObject var viewModel: AppViewModel
    var body: some View {
        NavigationView{
            if viewModel.signedIn{
                VistaPrincipal()
            }
            else{
                SignInView()
            }
            
        }
        .onAppear{
            viewModel.signedIn = viewModel.isSignedIn
        }
    }
    
}


struct SignInView: View {
    @State var username: String = ""
    @State var password: String = ""
    
    @EnvironmentObject var viewModel: AppViewModel
    var body: some View{
        VStack{
            VStack {
                Image("InicioSesion")
                    .resizable()
                    .scaledToFit()
            }
            .padding(.top, 20)
            Spacer()
            VStack{
                VStack(alignment: .leading) {
                    Text("Usuario")
                        .foregroundColor(colorBlanco)
                        .font(.system(size: 16, weight: .bold))
                    VStack {
                        TextField(
                                "User name (email address)",
                                text: $username
                        )
                        .padding(.horizontal, 10)
                        .padding(.vertical, 10)
                        .disableAutocorrection(/*@START_MENU_TOKEN@*/false/*@END_MENU_TOKEN@*/)
                        .autocapitalization(/*@START_MENU_TOKEN@*/.none/*@END_MENU_TOKEN@*/)
                    }
                    .overlay(Rectangle().stroke(colorBlanco, lineWidth: 1))
                }
                VStack(alignment: .leading) {
                    Text("Contraseña")
                        .foregroundColor(colorBlanco)
                        .font(.system(size: 16, weight: .bold))
                    VStack {
                        SecureField(
                                "***********",
                                text: $password
                        )
                        .padding(.horizontal, 10)
                        .padding(.vertical, 10)
                        .disableAutocorrection(/*@START_MENU_TOKEN@*/false/*@END_MENU_TOKEN@*/)
                        .autocapitalization(/*@START_MENU_TOKEN@*/.none/*@END_MENU_TOKEN@*/)
                    }
                    
                    .overlay(Rectangle().stroke(colorBlanco, lineWidth: 1))
                }
                Button(action:{
                    guard !username.isEmpty, !password.isEmpty else{
                        return
                    }
                    viewModel.signIn(email: username, password: password        )
                    veruser = username
                    verpass = password
                    print(veruser)
                },label:{
                    HStack{
                        Text("Iniciar Sesion")
                        
                    }
                    .padding(.vertical, 10)
                    .padding(.horizontal, 90)
                    .background(colorBotonPrincipal)
                    .foregroundColor(colorBlanco)
                    .cornerRadius(5)
                })
               
                
                Text("¿Olvidas tu contraseña?")
                    .foregroundColor(colorBlanco)
                    .font(.system(size: 14, weight: .semibold))

                Spacer()
                
                Text("¿Aún no posees una cuenta?")
                    .foregroundColor(colorBlanco)
                    .font(.system(size: 14, weight: .semibold))
                NavigationLink("Registrate", destination: SignUpView())
                
                .padding(.vertical, 10)
                .padding(.horizontal, 99)
                .background(colorBotonSecundario)
                .foregroundColor(colorBotonPrincipal)
                .cornerRadius(5)
                
                Spacer()
            }
            .frame(maxWidth: (UIScreen.main.bounds.width / 1.1))
            
            Spacer()
            
        }
        .ignoresSafeArea()
        .frame(minWidth:
                (UIScreen.main.bounds.width))
        .background(colorFondoPrincipal)
        .padding(.top, 0)
        
    }
}

struct SignUpView: View {
    @State var username: String = ""
    @State var password: String = ""
    @EnvironmentObject var viewModel: AppViewModel
    var body: some View{
        VStack{
            VStack {
                Image("InicioSesion")
                    .resizable()
                    .scaledToFit()
            }
            .padding(.top, 20)
            Spacer()
            VStack{
                VStack(alignment: .leading) {
                    Text("Usuario")
                        .foregroundColor(colorBlanco)
                        .font(.system(size: 16, weight: .bold))
                    VStack {
                        TextField(
                                "User name (email address)",
                                text: $username
                        )
                        .padding(.horizontal, 10)
                        .padding(.vertical, 10)
                        .autocapitalization(/*@START_MENU_TOKEN@*/.none/*@END_MENU_TOKEN@*/)
                        .disableAutocorrection(/*@START_MENU_TOKEN@*/false/*@END_MENU_TOKEN@*/)
                    }
                    .overlay(Rectangle().stroke(colorBlanco, lineWidth: 1))
                }
                VStack(alignment: .leading) {
                    Text("Contraseña")
                        .foregroundColor(colorBlanco)
                        .font(.system(size: 16, weight: .bold))
                    VStack {
                        SecureField(
                                "***********",
                                text: $password
                        )
                        .padding(.horizontal, 10)
                        .padding(.vertical, 10)
                        .autocapitalization(/*@START_MENU_TOKEN@*/.none/*@END_MENU_TOKEN@*/)
                        .disableAutocorrection(/*@START_MENU_TOKEN@*/false/*@END_MENU_TOKEN@*/)
                    }
                    
                    .overlay(Rectangle().stroke(colorBlanco, lineWidth: 1))
                }
                Button(action:{
                    guard !username.isEmpty, !password.isEmpty else{
                        return
                    }
                    viewModel.singUp(email: username, password: password)
                    let db = Firestore.firestore()
                    var ref : DocumentReference? = nil
                    ref = db.collection("Usuarios").addDocument(data: [
                            "correo":username,
                        "Contraseña": password
                    ]){err in if let err = err{print("Error de insercion\(err)")}
                        else
                        {
                            print("Insertado \(ref!.documentID)")
                        }
                    }
                    veruser=username
                    username = ""
                    password = ""
                    return
                    
                
                },label:{
                    HStack{
                        Text("Crear Cuenta")
                        
                    }
                    .padding(.vertical, 10)
                    .padding(.horizontal, 90)
                    .background(colorBotonPrincipal)
                    .foregroundColor(colorBlanco)
                    .cornerRadius(5)
                })
               
                

                Spacer()
                
                
                .padding(.vertical, 10)
                .padding(.horizontal, 99)
                .background(colorBotonSecundario)
                .foregroundColor(colorBotonPrincipal)
                .cornerRadius(5)
                
            }
            .frame(maxWidth: (UIScreen.main.bounds.width / 1.1))
            
            Spacer()
            
        }
        .ignoresSafeArea()
        .frame(minWidth:
                (UIScreen.main.bounds.width))
        .background(colorFondoPrincipal)
        .padding(.top, 0)
        
    }

}



struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
